<?php
$host = 'localhost';      
$user = 'root';           
$pass = '202312035';    
$dbname = 'login_db';     

// Membuat koneksi ke MySQL
$conn = new mysqli($host, $user, $pass, $dbname);

// Cek apakah koneksi berhasil
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
    
}
echo"berhasil sodara";
?>