<?php
session_start();

$username = $_POST['username'];
$password = $_POST['password'];

// Contoh pengecekan sederhana
if ($username == "cahaya" && $password == "12345") {
    $_SESSION['username'] = $username;
    header("Location: welcome.php");
    exit();
} else {
    echo "Login gagal. <a href='index.html'>Coba lagi</a>";
}
?>