<!-- welcome.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Welcome</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="style.css" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="container mt-5 welcome-container text-center">
        <h2>Selamat datang, Cahaya!</h2>
        <p>Semoga harimu menyenangkan ✨</p>
        <a href="logout.php" class="btn btn-light mt-3">Logout</a>
    </div>
</body>

</html>